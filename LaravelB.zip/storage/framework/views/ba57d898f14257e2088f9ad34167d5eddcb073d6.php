<?php $__env->startSection('title'); ?>
Edit <?php echo e($posts->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">
.btn-default,
.btn-default:hover {
    color: #FFF;
    background-color: #d80857;
    border-color: #E91E63;
    margin-bottom: 10px;
    font-weight: bold;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if(Session::has('success')): ?>
<div class="alert alert-success">
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>
<?php if(count($errors) > 0): ?>
 <div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
 </div>
<?php endif; ?>
    <div class="col-lg-12 col-md-12">
        <form class="form-horizontal"  
                  action="<?php echo e(url('admin/post/'.$posts->id.'/update')); ?>" 
                  method="post"
                  enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label class="control-label col-sm-2" for="title">Title</label>
                    <div class="col-sm-10">
                      <input type="text" name="title" value="<?php echo e($posts->title); ?>" class="form-control" id="title" placeholder="Enter Title">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-2" for="body">Body</label>
                    <div class="col-sm-10"> 
                      <textarea class="form-control" name="body" id="body" rows="15">
                        <?php echo e($posts->body); ?>

                      </textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-2" for="image">Image</label>
                    <div class="col-sm-10"> 
                      <?php echo e($posts->image); ?>

                      <input type="file" name="image" value="<?php echo e($posts->image); ?>" class="form-control" id="image" />
                    </div>
                  </div>
                  <div class="form-group"> 
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-success">Add New Post</button>
                    </div>
                  </div>
                  <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
            </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>