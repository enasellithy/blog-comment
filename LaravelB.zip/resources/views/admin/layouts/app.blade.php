@include('admin.layouts.head')
@include('admin.layouts.nav')
@include('admin.layouts.footer')