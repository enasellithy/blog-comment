<div id="page-wrapper">

            <div class="container-fluid">

                

               @yield('content')

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="{{url('public/back-end')}}/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{url('public/back-end')}}/js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="{{url('public/back-end')}}/js/plugins/morris/raphael.min.js"></script>
    <script src="{{url('public/back-end')}}/js/plugins/morris/morris.min.js"></script>
    <script src="{{url('public/back-end')}}/js/plugins/morris/morris-data.js"></script>

</body>

</html>