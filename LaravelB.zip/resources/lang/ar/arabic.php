<?php

return [
 'Start Bootstrap'      => 'الرئيسية',
 'Login'                => 'تسجيل الدخول',
 'Register'             => 'التسجيل',
 'Logout'               => 'تسجيل الخروج',
 'Name'                 => 'الاسم',
 'E-Mail Address'       => 'البريد الالكترونى',
 'Password'             => 'كلمة السر',
 'Confirm Password'     => 'تأكيد كلمه السر',
 'Remember Me'          => 'تذكرنى',
 'Forgot Your Password' => 'نسيت كلمه السر',
 'Clean Blog'           => 'مودرن',
 'Copyright'            => 'جميع الحقوق محفوظه',
 'delete'				=> 'حذف',
 'Admin Panel'			=> 'لوحة التحكم',
];