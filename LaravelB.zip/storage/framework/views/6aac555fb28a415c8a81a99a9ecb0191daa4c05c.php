<?php $__env->startSection('title'); ?>
Nice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-preview">
                    <a href="post/<?php echo e($post->id); ?>/show">
                        <h2 class="post-title">
                            <?php echo e($post->titel); ?>

                        </h2>
                        <img src="<?php echo e(url('public/images/'.$post->image)); ?>"
                         class="img-responsive img-circle"
                         width="100"
                         height="100" 
                         title="blog"
                         alt="blog" />
                        <h3 class="post-subtitle">
                            <?php echo e($post->title); ?>

                        </h3>
                    </a>

                    <p>
                        <?php echo e(substr($post->body, 0, 25)); ?>

                        <?php echo e(strlen($post->body) > 200 ? "...":""); ?>

                    </p>
                    <p class="post-meta">Posted by 
                        <a href="#"><?php echo e(App\User::find($post->user_id)->name); ?></a> 
                        <?php echo e(date('M j, Y ',strtotime($post->created_at))); ?>

                    </p>
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Pager -->
                <div class="pager text-center">
                    <?php echo $posts->links(); ?>

                </div>
            </div>
        </div>
    </div>

    <hr>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>