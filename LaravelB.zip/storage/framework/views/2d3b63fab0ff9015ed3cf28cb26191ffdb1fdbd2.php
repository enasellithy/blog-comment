<?php $__env->startSection('title'); ?>
Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">
.btn-default,
.btn-default:hover {
    color: #FFF;
    background-color: #d80857;
    border-color: #E91E63;
    margin-bottom: 10px;
    font-weight: bold;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
<div class="alert alert-success">
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>
<?php if(count($errors) > 0): ?>
 <div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
 </div>
<?php endif; ?>
<div class="row">
    <div class="col-xs-3">
        <a href="<?php echo e(route('post.create')); ?>" class="btn btn-default">Create New Post</a>
    </div>
    <div class="col-lg-12 col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge">Posts</div>
                        <div class="count">2</div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <table class="table table-hover table-bordered">
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Body</th>
                            <th>By</th>
                            <th>Control</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($post->id); ?></td>
                            <td><?php echo e($post->title); ?></td>
                            <td>
                                <?php echo e(substr($post->body, 0, 25)); ?>

                                <?php echo e(strlen($post->body) > 25 ? "...":""); ?>

                                <div>
                                    <?php echo e(date('M j, Y ',strtotime($post->created_at))); ?>

                                </div>
                            </td>
                            <td><?php echo e(App\User::find($post->user_id)->name); ?></td>
                            <td>
                                <a href="post/<?php echo e($post->id); ?>/edit" class="btn btn-info">Edit</a>
                                <a href="post/<?php echo e($post->id); ?>/delete" class="btn btn-danger">Delete</a>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
</div>
<div class="col-lg-6 col-md-6 text-center">
            <?php echo $posts->links(); ?>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>